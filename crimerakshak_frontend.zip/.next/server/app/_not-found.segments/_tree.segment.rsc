:HL["/_next/static/chunks/0s5jt4llqt1u5.css","style"]
:HL["/_next/static/chunks/3zs_yph81j5mh.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"dVExAwNEQcuHWUVQAmi03"}
