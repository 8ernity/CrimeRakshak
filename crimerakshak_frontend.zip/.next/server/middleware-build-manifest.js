globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/dVExAwNEQcuHWUVQAmi03/_buildManifest.js",
    "static/dVExAwNEQcuHWUVQAmi03/_ssgManifest.js",
    "static/dVExAwNEQcuHWUVQAmi03/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/37v5ulr6qjozi.js",
    "static/chunks/1rm737diirj6u.js",
    "static/chunks/0v2vpvr62y-mj.js",
    "static/chunks/2ejk_26znfoeu.js",
    "static/chunks/228oj19jyxe16.js",
    "static/chunks/0g8ku62w0yb2s.js",
    "static/chunks/3cjax0pm491q4.js",
    "static/chunks/turbopack-32y8mwqnvvidl.js"
  ]
};
