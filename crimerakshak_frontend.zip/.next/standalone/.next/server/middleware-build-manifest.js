globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/-i60K-jHUKR8SsZ3xZEj9/_buildManifest.js",
    "static/-i60K-jHUKR8SsZ3xZEj9/_ssgManifest.js",
    "static/-i60K-jHUKR8SsZ3xZEj9/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/37v5ulr6qjozi.js",
    "static/chunks/1rm737diirj6u.js",
    "static/chunks/2nu73za84o-k3.js",
    "static/chunks/2ejk_26znfoeu.js",
    "static/chunks/228oj19jyxe16.js",
    "static/chunks/0g8ku62w0yb2s.js",
    "static/chunks/3cjax0pm491q4.js",
    "static/chunks/turbopack-40_l1h2q2n22b.js"
  ]
};
