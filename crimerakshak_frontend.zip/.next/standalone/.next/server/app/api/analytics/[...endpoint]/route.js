var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/[...endpoint]/route.js")
R.c("server/chunks/[root-of-the-server]__1gdqh59._.js")
R.c("server/chunks/node_modules_next_dist_1_lpwll._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_._.js")
R.c("server/chunks/node_modules_0t5_ff-._.js")
R.c("server/chunks/_next-internal_server_app_api_analytics_[___endpoint]_route_actions_12kjy1z.js")
R.m(937042)
module.exports=R.m(937042).exports
