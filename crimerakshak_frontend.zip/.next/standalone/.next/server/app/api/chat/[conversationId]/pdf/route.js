var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/[conversationId]/pdf/route.js")
R.c("server/chunks/[root-of-the-server]__1uvplq8._.js")
R.c("server/chunks/node_modules_next_dist_0roered._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_._.js")
R.c("server/chunks/node_modules_0t5_ff-._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_[conversationId]_pdf_route_actions_1z9qf_x.js")
R.m(967366)
module.exports=R.m(967366).exports
