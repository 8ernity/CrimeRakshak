var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/[root-of-the-server]__0-l0uaz._.js")
R.c("server/chunks/node_modules_next_dist_0roered._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_._.js")
R.c("server/chunks/node_modules_0t5_ff-._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_route_actions_1d_pld-.js")
R.m(899280)
module.exports=R.m(899280).exports
