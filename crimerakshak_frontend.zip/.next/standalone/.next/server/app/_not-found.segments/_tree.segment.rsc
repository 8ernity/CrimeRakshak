:HL["/_next/static/chunks/0s5jt4llqt1u5.css","style"]
:HL["/_next/static/chunks/2ppx1e3ckcd3e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"-i60K-jHUKR8SsZ3xZEj9"}
