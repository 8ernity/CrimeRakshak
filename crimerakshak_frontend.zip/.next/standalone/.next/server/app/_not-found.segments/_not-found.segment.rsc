1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/1s1redcasc8_r.js","/_next/static/chunks/0oa6a_cf5w8fp.js","/_next/static/chunks/32jx3lq2xiz5u.js","/_next/static/chunks/0ttybpviudx_a.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
3:I[837457,["/_next/static/chunks/1s1redcasc8_r.js","/_next/static/chunks/0oa6a_cf5w8fp.js","/_next/static/chunks/32jx3lq2xiz5u.js","/_next/static/chunks/0ttybpviudx_a.js","/_next/static/chunks/1ntn7efqc-iiw.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"-i60K-jHUKR8SsZ3xZEj9"}
