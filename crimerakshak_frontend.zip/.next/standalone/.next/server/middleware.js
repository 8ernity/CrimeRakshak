var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__1wmz_i7._.js")
R.c("server/chunks/[root-of-the-server]__010dd-r._.js")
R.c("server/chunks/node_modules_next_dist_1-3cdou._.js")
R.m(489997)
module.exports=R.m(489997).exports
