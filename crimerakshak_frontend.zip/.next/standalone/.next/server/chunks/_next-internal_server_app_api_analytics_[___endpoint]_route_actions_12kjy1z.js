module.exports=[279745,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_analytics_%5B___endpoint%5D_route_actions_12kjy1z.js.map